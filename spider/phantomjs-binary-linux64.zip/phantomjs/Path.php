<?php
namespace Anam\PhantomLinux;

class Path
{
    public static function binaryPath()
    {
        return __DIR__.'/bin/phantomjs';
    }
}
